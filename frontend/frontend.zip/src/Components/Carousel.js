import React from 'react'

function Carousel() {
  return (
    <>
      {/*=====================slider area start=========================*/}
      <div className="slider_section mb-60">
        <div className="container-fluid">
          <div className="row">
            <div className="col-lg-12">
              <div className="slider_area slider-two slider-three slider-tools row">
                {/* Single Slider Start */}
                <div className="single_slider hero-bg-3">
                </div>
                {/* Single Slider End */}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/*======================slider area End==========================*/}
    </>
  )
}

export default Carousel