import React from 'react'
import BlogGrid from '../Components/BlogGrid'

function BlogPage() {
  return (
   <>
   <BlogGrid />
   </>
  )
}

export default BlogPage