import React from 'react'

function ProductDetailPage() {
  return (
    <>
    </>
  )
}

export default ProductDetailPage