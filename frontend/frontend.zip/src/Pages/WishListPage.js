import React from 'react'

function WishListPage() {
  return (
    <div>WishListPage</div>
  )
}

export default WishListPage